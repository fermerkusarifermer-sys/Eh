/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  BrowserRouter as Router, 
  Routes, 
  Route, 
  Link, 
  useLocation, 
  useNavigate 
} from 'react-router-dom';
import { 
  Bell, 
  Search, 
  MessageCircle, 
  Menu, 
  User, 
  Wallet, 
  Heart, 
  ShoppingCart, 
  ChevronRight, 
  Globe, 
  Instagram, 
  Twitter, 
  Gamepad2, 
  Gift, 
  Headset, 
  Trophy, 
  X, 
  CircleUser, 
  LayoutDashboard, 
  LogOut, 
  Star,
  Plus,
  Minus,
  Check,
  Disc,
  ArrowRight,
  CreditCard,
  History,
  Bolt,
  ShieldCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

import { LANGUAGES, CURRENCIES, GAME_CATEGORIES } from './constants';
import { Currency, Language, Product } from './types';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- CONFIGURATION & LINKS ---
// Bu bölümden tüm logoları ve görselleri kolayca değiştirebilirsiniz:
const GLOBAL_LINKS = {
  LOGO_MAIN: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnkeonUE2T3u38vWsnRi0DjVoQGY-FkOm3m02wqOyUiw&s=10', // Ana logo
  LOGO_ICON: 'https://vatangame.az/storage/uploads/settings/favicon-777647.webp', // Küçük ikon logo
  BANNER_PUBG: 'https://cdn.cimri.io/image/860x860/pubg-mobile-royale-pass-paket_649799865.jpg',
  BANNER_VALORANT: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSU4W0DJtL2AijzogZ6FIYPdQvo_qPqPe9ybTTWp9xfGLKtozl-3QIOqIs&s=10',
  BANNER_BRAWL: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTk64AQ25bSrg_5bLavxwWRhRDumcSpM3fy2GK_mP_K9-x77KaFvbSp41U&s=10',
  PRODUCT_PUBG: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRp1Pztt7qerktH5Z60ZM9wXldTwtIqpNuqQ&s',
  PRODUCT_VALORANT: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2vKCuXABAJuYvrxWcWV98KjwoIpYZLHDNcvr0kESESQ&s',
  PRODUCT_MLBB: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2CAzIIZcgYKsId0GRBkQUKY6Yjq5WO1a8PrRCgfb_Fw&s',
  PRODUCT_STEAM: ''https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQw13veNXNd-6o-tNQOE2Iv4lYOcaqz9-z7eK4WQRh6Ew&s,
  PRODUCT_BRAWL: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJdoC5smtS9Fi4uVL3pe0oLM1X-u5gcJwktyydS07jLrhUDTrPG3AdxLbZ&s=10',
  PRODUCT_FREEFIRE: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQS_7-EyAzBHiGB51ZdpAfYUAM1oqLG-FJV1d9S11c_z2IwWOwabvINtoU&s',
};

// --- MOCK DATA ---
const BANNERS = [
  { id: 1, title: 'PUBG MOBILE: MYTHIC FORCE', subtitle: 'HƏMİŞƏ AKTİV!', color: 'from-yellow-600', image: GLOBAL_LINKS.BANNER_PUBG },
  { id: 2, title: 'VALORANT: KURONAMI', subtitle: 'EKSKLÜZİV PAKET', color: 'from-amber-600', image: GLOBAL_LINKS.BANNER_VALORANT },
  { id: 3, title: 'BRAWL STARS: ELMAS', subtitle: 'GÜNLÜK ENDİRİM!', color: 'from-yellow-500', image: GLOBAL_LINKS.BANNER_BRAWL },
];

const QUICK_SHORTCUTS = [
  'PUBG Mobile UC', 'Valorant VP', 'LoL RP', 'Mobile Legends', 'Steam', 'Free Fire', 'Robux', 'Brawl Stars'
];

const MOCK_PRODUCTS: Product[] = [
  // PUBG MOBILE
  { id: 'p1', name: '60 UC Global', game: 'PUBG Mobile', category: 'UC', price: 0.99, image: GLOBAL_LINKS.PRODUCT_PUBG, seller: 'EpinCloud', rating: 4.9, stock: 5000 },
  { id: 'p2', name: '325 UC Global', game: 'PUBG Mobile', category: 'UC', price: 4.85, image: GLOBAL_LINKS.PRODUCT_PUBG, seller: 'ProGamer', rating: 4.8, stock: 1200 },
  { id: 'p3', name: '660 UC Global', game: 'PUBG Mobile', category: 'UC', price: 9.60, image: GLOBAL_LINKS.PRODUCT_PUBG, seller: 'EpinCloud', rating: 4.9, stock: 800 },
  { id: 'p4', name: '1800 UC Global', game: 'PUBG Mobile', category: 'UC', price: 23.99, image: GLOBAL_LINKS.PRODUCT_PUBG, seller: 'EpinCloud', rating: 4.9, stock: 300 },
  { id: 'p5', name: '3850 UC Global', game: 'PUBG Mobile', category: 'UC', price: 47.50, image: GLOBAL_LINKS.PRODUCT_PUBG, seller: 'EpinCloud', rating: 5.0, stock: 150 },
  { id: 'p6', name: '8100 UC Global', game: 'PUBG Mobile', category: 'UC', price: 94.00, image: GLOBAL_LINKS.PRODUCT_PUBG, seller: 'TopSeller', rating: 5.0, stock: 100 },

  // VALORANT TR
  { id: 'v1', name: '1150 Valorant Points (TR)', game: 'Valorant', category: 'VP', price: 11.20, image: GLOBAL_LINKS.PRODUCT_VALORANT, seller: 'RiotReseller', rating: 5.0, stock: 850 },
  { id: 'v2', name: '2850 Valorant Points (TR)', game: 'Valorant', category: 'VP', price: 27.50, image: GLOBAL_LINKS.PRODUCT_VALORANT, seller: 'EpinCloud', rating: 5.0, stock: 400 },
  { id: 'v3', name: '5250 Valorant Points (TR)', game: 'Valorant', category: 'VP', price: 48.90, image: GLOBAL_LINKS.PRODUCT_VALORANT, seller: 'EpinCloud', rating: 5.0, stock: 200 },
  { id: 'v4', name: '8500 Valorant Points (TR)', game: 'Valorant', category: 'VP', price: 78.00, image: GLOBAL_LINKS.PRODUCT_VALORANT, seller: 'EpinCloud', rating: 5.0, stock: 100 },

  // BRAWL STARS
  { id: 'b1', name: '30 Gems', game: 'Brawl Stars', category: 'ELMAS', price: 2.10, image: GLOBAL_LINKS.PRODUCT_BRAWL, seller: 'SuperCell', rating: 4.8, stock: 2000 },
  { id: 'b2', name: '80 Gems', game: 'Brawl Stars', category: 'ELMAS', price: 5.40, image: GLOBAL_LINKS.PRODUCT_BRAWL, seller: 'SuperCell', rating: 4.9, stock: 1500 },
  { id: 'b3', name: '170 Gems', game: 'Brawl Stars', category: 'ELMAS', price: 10.99, image: GLOBAL_LINKS.PRODUCT_BRAWL, seller: 'SuperCell', rating: 4.9, stock: 800 },
  { id: 'b4', name: '360 Gems', game: 'Brawl Stars', category: 'ELMAS', price: 21.50, image: GLOBAL_LINKS.PRODUCT_BRAWL, seller: 'SuperCell', rating: 5.0, stock: 400 },
  { id: 'b5', name: '950 Gems', game: 'Brawl Stars', category: 'ELMAS', price: 54.00, image: GLOBAL_LINKS.PRODUCT_BRAWL, seller: 'SuperCell', rating: 5.0, stock: 200 },

  // MOBILE LEGENDS
  { id: 'm1', name: 'Weekly Diamond Pass', game: 'Mobile Legends', category: 'PASS', price: 2.15, image: GLOBAL_LINKS.PRODUCT_MLBB, seller: 'MLSeller', rating: 4.9, stock: 5000 },
  { id: 'm2', name: '285 Diamonds', game: 'Mobile Legends', category: 'ELMAS', price: 5.50, image: GLOBAL_LINKS.PRODUCT_MLBB, seller: 'StarSellers', rating: 4.7, stock: 1250 },
  { id: 'm3', name: '706 Diamonds', game: 'Mobile Legends', category: 'ELMAS', price: 13.20, image: GLOBAL_LINKS.PRODUCT_MLBB, seller: 'StarSellers', rating: 4.8, stock: 600 },

  // STEAM
  { id: 's1', name: '$10 Steam Gift Card', game: 'Steam', category: 'CÜZDAN', price: 10.00, image: GLOBAL_LINKS.PRODUCT_STEAM, seller: 'EpinCloud', rating: 5.0, stock: 1000 },
  { id: 's2', name: '$20 Steam Gift Card', game: 'Steam', category: 'CÜZDAN', price: 20.00, image: GLOBAL_LINKS.PRODUCT_STEAM, seller: 'EpinCloud', rating: 5.0, stock: 500 },
  { id: 's3', name: '$50 Steam Gift Card', game: 'Steam', category: 'CÜZDAN', price: 50.00, image: GLOBAL_LINKS.PRODUCT_STEAM, seller: 'EpinCloud', rating: 5.0, stock: 200 },

  // FREE FIRE
  { id: 'f1', name: '100 Diamonds', game: 'Free Fire', category: 'ELMAS', price: 1.05, image: GLOBAL_LINKS.PRODUCT_FREEFIRE, seller: 'Garena', rating: 4.6, stock: 1500 },
  { id: 'f2', name: '210 Diamonds', game: 'Free Fire', category: 'ELMAS', price: 2.10, image: GLOBAL_LINKS.PRODUCT_FREEFIRE, seller: 'Garena', rating: 4.7, stock: 1000 },
  { id: 'f3', name: '530 Diamonds', game: 'Free Fire', category: 'ELMAS', price: 5.25, image: GLOBAL_LINKS.PRODUCT_FREEFIRE, seller: 'Garena', rating: 4.7, stock: 1000 },

  // LEAGUE OF LEGENDS
  { id: 'l1', name: '575 RP', game: 'League of Legends', category: 'RP', price: 4.50, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2CAzIIZcgYKsId0GRBkQUKY6Yjq5WO1a8PrRCgfb_Fw&s", seller: 'EpinCloud', rating: 4.9, stock: 1000 },
  { id: 'l2', name: '1380 RP', game: 'League of Legends', category: 'RP', price: 10.50, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2CAzIIZcgYKsId0GRBkQUKY6Yjq5WO1a8PrRCgfb_Fw&s", seller: 'EpinCloud', rating: 5.0, stock: 500 },
  { id: 'l3', name: '2800 RP', game: 'League of Legends', category: 'RP', price: 21.00, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2CAzIIZcgYKsId0GRBkQUKY6Yjq5WO1a8PrRCgfb_Fw&s", seller: 'EpinCloud', rating: 5.0, stock: 200 },

  // GIFT CARDS
  { id: 'g1', name: '$10 Netflix Gift Card', game: 'Netflix', category: 'GIFT', price: 10.50, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRukWg1QkI5My4pycii5BToiUNUtlYpIgBTB4QUn59sAg&s=10", seller: 'EpinCloud', rating: 4.9, stock: 100 },
  { id: 'g2', name: '$25 Netflix Gift Card', game: 'Netflix', category: 'GIFT', price: 25.99, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRukWg1QkI5My4pycii5BToiUNUtlYpIgBTB4QUn59sAg&s=10", seller: 'EpinCloud', rating: 5.0, stock: 50 },
  { id: 'g3', name: 'Discord Nitro (1 Month)', game: 'Discord', category: 'GIFT', price: 9.99, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1nKXI1dEPFQfJrz_rSJutD45oxbgoJfdFynngok_r7Q&s", seller: 'EpinCloud', rating: 5.0, stock: 300 },
];


// --- COMPONENTS ---

const Header = ({ 
  onLangClick, 
  currentLang, 
  currentCurrency,
  currentUser,
  setSellModalOpen,
  cartCount 
}: any) => {
  const [search, setSearch] = useState('');
  const [showSearchHistory, setShowSearchHistory] = useState(false);

  return (
    <header className="fixed top-0 left-0 w-full z-[100]">
      {/* Top Bar */}
      <div className="bg-[#050505] text-[10px] font-black border-b border-white/5 py-2 px-4 md:px-8 hidden md:flex items-center justify-between uppercase tracking-[0.1em]">
        <div className="flex items-center gap-6">
          <Link to="#" className="text-gray-500 hover:text-primary transition-colors flex items-center gap-2 text-glow"><Instagram size={12} /> epincloud.az</Link>
          <Link to="#" className="text-gray-500 hover:text-primary transition-colors flex items-center gap-2 text-glow"><Disc size={12} /> Discord</Link>
          <Link to="#" className="text-gray-500 hover:text-primary transition-colors flex items-center gap-2 text-glow"><MessageCircle size={12} /> WhatsApp</Link>
        </div>
        <div className="flex items-center gap-8">
          {currentUser?.role === 'admin' && (
            <Link to="/admin" className="text-primary hover:brightness-110 font-black border-r border-white/5 pr-4 tracking-tighter flex items-center gap-1">
              <ShieldCheck size={12} /> SİSTEM İDARƏ
            </Link>
          )}
          <Link to="/become-a-seller" className="text-gray-400 hover:text-white transition-colors">Satıcı Ol</Link>
          <Link to="/streamers" className="text-gray-400 hover:text-white">Yayınçılar</Link>
          <Link to="/help-center" className="text-gray-400 hover:text-white">Dəstək Mərkəzi</Link>
          <Link to="/wallet" className="text-primary font-black flex items-center gap-2 group bg-primary/5 px-4 py-1.5 rounded-full border border-primary/20 hover:bg-primary/10 transition-all shadow-inner">
             <Wallet size={14} className="text-primary" /> 
             {currentCurrency.symbol}{currentUser?.balance?.toFixed(2) || '0.00'}
          </Link>
          <button 
            className="bg-primary text-black px-4 py-1.5 rounded-full font-black hover:scale-105 active:scale-95 transition-all text-[10px] uppercase tracking-widest shadow-[0_0_20px_rgba(250,204,21,0.2)]"
            onClick={() => setSellModalOpen(true)}
          >
            SÜRƏTLİ SATIŞ
          </button>
          <button 
            onClick={onLangClick}
            className="flex items-center gap-2 hover:text-primary transition-colors border-l border-white/5 pl-4"
          >
            <div className="w-5 h-5 rounded-full overflow-hidden border border-white/10 shadow-sm">
              <img src={currentLang.flag} alt={currentLang.name} className="w-full h-full object-cover" />
            </div>
            <span className="text-xs font-bold uppercase tracking-widest">{currentLang.code}</span>
          </button>
        </div>
      </div>
      
      {/* Main Nav */}
      <nav className="glass border-b border-white/5 py-4 px-4 md:px-8 relative overflow-hidden">
        <div className="scanline" />
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 relative z-10">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center transform group-hover:rotate-12 transition-all group-hover:border-primary/50 shadow-inner p-1 overflow-hidden">
              <img src={GLOBAL_LINKS.LOGO_ICON} alt="Icon" className="w-full h-full object-contain" />
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-black tracking-tighter leading-none italic text-white flex items-center line-clamp-1">
                EPIN<span className="text-primary">CLOUD</span>
              </span>
              <span className="text-[9px] font-black tracking-[0.4em] text-primary uppercase ml-0.5 opacity-80">Gaming Authority</span>
            </div>
          </Link>

          {/* Search */}
          <div className="flex-1 relative max-w-2xl hidden lg:block">
            <div className="relative group">
              <input 
                type="text" 
                placeholder="Oyun, kod və ya satıcı axtar..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onFocus={() => setShowSearchHistory(true)}
                onBlur={() => setTimeout(() => setShowSearchHistory(false), 200)}
                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 pl-14 pr-6 text-sm focus:bg-white/10 focus:border-primary/50 outline-none transition-all placeholder:text-gray-600 font-medium shadow-inner"
              />
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-primary transition-colors" size={20} />
            </div>
            <AnimatePresence>
              {showSearchHistory && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute top-full mt-3 left-0 w-full glass border border-white/10 rounded-2xl p-6 shadow-2xl z-50 card-gradient"
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[10px] font-black text-primary tracking-widest uppercase">Son Axtarışlar</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {['PUBG Mobile', 'Valorant VP', 'Brawl Stars', 'Steam Code'].map(item => (
                      <span key={item} className="px-4 py-2 bg-white/5 rounded-xl text-xs font-bold hover:bg-primary hover:text-black cursor-pointer transition-all border border-white/5">
                        {item}
                      </span>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="flex items-center gap-3">
             <Link to="/cart" className="relative p-3 bg-white/5 rounded-2xl border border-white/5 hover:border-primary/30 transition-all group shadow-inner">
                <ShoppingCart size={22} className="text-gray-400 group-hover:text-primary" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary text-[10px] flex items-center justify-center rounded-full text-black font-black yellow-glow">
                    {cartCount}
                  </span>
                )}
              </Link>
              
              <div className="relative p-3 bg-white/5 rounded-2xl border border-white/10 hover:border-primary/30 transition-all group cursor-pointer hidden md:block shadow-inner">
                <Bell size={22} className="text-gray-400 group-hover:text-primary" />
                <span className="absolute top-3 right-3 w-2 h-2 bg-primary rounded-full border-2 border-dark-card" />
              </div>

              <div className="h-10 w-[1px] bg-white/5 mx-2 hidden md:block" />

              {currentUser ? (
                <Link to="/profile" className="flex items-center gap-3 group pl-2">
                  <div className="hidden md:flex flex-col text-right">
                    <span className="text-[11px] font-black tracking-tight text-white uppercase italic">{currentUser.username}</span>
                    <span className="text-[9px] font-bold text-primary uppercase tracking-[0.2em]">{currentUser.role}</span>
                  </div>
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-primary to-secondary p-[1px] shadow-lg group-hover:scale-105 transition-transform">
                    <div className="w-full h-full bg-dark-card rounded-[inherit] flex items-center justify-center text-primary font-black uppercase text-xl">
                      {currentUser.username[0]}
                    </div>
                  </div>
                </Link>
              ) : (
                <div className="flex items-center gap-2">
                  <Link to="/login" className="px-6 py-3 font-black text-xs uppercase tracking-widest hover:text-primary transition-colors hidden md:block">Daxil Ol</Link>
                  <Link to="/register" className="px-6 py-3 bg-primary text-black rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/20 hover:scale-105 active:scale-95 transition-all">Qeydiyyat</Link>
                </div>
              )}
          </div>
        </div>
      </nav>

      {/* Category Nav */}
      <div className="bg-[#0c0c0e]/80 backdrop-blur-md border-b border-white/5 overflow-x-auto no-scrollbar">
        <div className="max-w-7xl mx-auto flex items-center justify-center md:justify-start px-4">
          <div className="flex items-center overflow-x-auto no-scrollbar">
            {GAME_CATEGORIES.map((cat) => (
              <Link 
                key={cat.id} 
                to={cat.path}
                className="flex items-center gap-2.5 px-5 py-4 whitespace-nowrap text-[10px] font-black text-gray-500 hover:text-white border-b-2 border-transparent hover:border-primary transition-all group uppercase tracking-widest"
              >
                <div className="p-1 px-1.5 rounded-lg bg-white/5 group-hover:bg-primary/20 group-hover:text-primary transition-colors shadow-inner">
                   <Gamepad2 size={14} />
                </div>
                {cat.name}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
};

const Footer = () => {
  return (
    <footer className="bg-[#0f0f12] pt-16 pb-32 md:pb-16 px-4 md:px-8 border-t border-white/5 mt-auto">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
        <div>
          <h3 className="text-lg font-bold mb-6 text-white uppercase tracking-wider">Popular Categories</h3>
          <ul className="space-y-3 text-sm text-gray-500">
            {['PUBG Mobile UC', 'Valorant VP', 'Mobile Legends Diamonds', 'Free Fire Diamonds', 'LoL RP', 'Clash of Clans Gems', 'Brawl Stars Gems'].map((item) => (
              <li key={item}><Link to="#" className="hover:text-primary transition-colors">{item}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="text-lg font-bold mb-6 text-white uppercase tracking-wider">Corporate</h3>
          <ul className="space-y-3 text-sm text-gray-500">
            <li><Link to="/about" className="hover:text-primary transition-colors">About Us</Link></li>
            <li><Link to="/help-center" className="hover:text-primary transition-colors">Help Center</Link></li>
            <li><Link to="/streamers" className="hover:text-primary transition-colors">Streamer Program</Link></li>
            <li><Link to="/become-a-seller" className="hover:text-primary transition-colors">Become a Seller</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="text-lg font-bold mb-6 text-white uppercase tracking-wider">Legal</h3>
          <ul className="space-y-3 text-sm text-gray-500">
            <li><Link to="/privacy-policy" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
            <li><Link to="/user-agreement" className="hover:text-primary transition-colors">User Agreement</Link></li>
            <li><Link to="/sales-agreement" className="hover:text-primary transition-colors">Sales Agreement</Link></li>
            <li><Link to="/cancellation-policy" className="hover:text-primary transition-colors">Refund Policy</Link></li>
            <li><Link to="/cookie-policy" className="hover:text-primary transition-colors">Cookie Policy</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="text-lg font-bold mb-6 text-white uppercase tracking-wider">Contact</h3>
          <div className="space-y-4 text-sm text-gray-500">
            <p>Customer Service Email:<br/><span className="text-primary">support@epincloud.com</span></p>
            <div className="flex gap-4 mt-6">
              <Link to="#" className="p-2 bg-white/5 rounded-lg hover:bg-primary/20 hover:text-primary transition-all"><Instagram size={20} /></Link>
              <Link to="#" className="p-2 bg-white/5 rounded-lg hover:bg-primary/20 hover:text-primary transition-all"><Twitter size={20} /></Link>
              <Link to="#" className="p-2 bg-white/5 rounded-lg hover:bg-primary/20 hover:text-primary transition-all"><Disc size={20} /></Link>
            </div>
            <div className="flex gap-2 items-center mt-6 h-8 opacity-60">
              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQo92v0kGrgqUuJL_gzVzd3NKxXthSqWwUcygOcMXk&usqp=CAE&s" className="h-full" alt="Visa" />
              <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" className="h-full" alt="Mastercard" />
            </div>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-600">
        <p>© 2026 Epincloud. All Rights Reserved.</p>
        <p>A Gaming Brands subsidiary.</p>
      </div>
    </footer>
  );
};

// --- COMPONENTS ---

const LiveSupport = () => (
  <motion.button 
    initial={{ scale: 0, opacity: 0 }}
    animate={{ scale: 1, opacity: 1 }}
    whileHover={{ scale: 1.1 }}
    whileTap={{ scale: 0.9 }}
    className="fixed bottom-24 md:bottom-8 right-8 z-[100] w-16 h-16 bg-primary text-black rounded-full shadow-[0_10px_40px_rgba(250,204,21,0.4)] flex items-center justify-center group"
  >
    <MessageCircle size={32} />
    <span className="absolute right-full mr-4 bg-dark-card border border-white/10 px-4 py-2 rounded-xl text-xs font-bold text-white whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
      DƏSTƏK İLƏ DANIŞ
    </span>
    <span className="absolute -top-1 -right-1 w-5 h-5 bg-green-500 border-4 border-dark-bg rounded-full animate-pulse" />
  </motion.button>
);

const ProductCard = ({ product, onBuy }: any) => {
  const isBestSeller = product.rating >= 4.9;
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-dark-card border border-white/5 rounded-[32px] overflow-hidden hover:border-primary/50 transition-all group flex flex-col h-full relative"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-[#111115]">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-contain p-4 group-hover:scale-110 transition-transform duration-700 opacity-90 group-hover:opacity-100"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        
        <button className="absolute top-4 right-4 p-2.5 rounded-2xl bg-black/40 backdrop-blur-md opacity-0 group-hover:opacity-100 transition-all text-white hover:text-red-500 hover:bg-white/10">
          <Heart size={18} />
        </button>
        
        <div className="absolute bottom-4 left-4 flex flex-col gap-2">
          {isBestSeller && (
            <div className="px-3 py-1 bg-yellow-500 text-black text-[9px] font-black rounded-lg w-fit shadow-lg italic">BEST SELLER</div>
          )}
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded-xl text-[10px] font-black text-primary border border-primary/20">
            <div className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" /> ANİ ÇATDIRILMA
          </div>
        </div>
      </div>

      <div className="p-6 flex flex-col flex-1">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">{product.category}</span>
          <div className="flex items-center gap-1 text-[10px] text-primary font-black">
            <Star size={12} fill="currentColor" /> {product.rating}
          </div>
        </div>
        
        <h3 className="text-base font-bold mb-3 group-hover:text-primary transition-colors line-clamp-1 italic">{product.name}</h3>
        
        <div className="flex items-center gap-2 mb-6">
           <div className="w-6 h-6 rounded-full bg-white/5 flex items-center justify-center text-[10px] text-gray-400 font-bold border border-white/5">
             {product.seller[0]}
           </div>
           <span className="text-[11px] text-gray-500 font-medium">Satıcı: <span className="text-white font-bold">{product.seller}</span></span>
        </div>
        
        <div className="mt-auto pt-6 border-t border-white/5 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-[9px] text-gray-500 uppercase font-black tracking-widest leading-none mb-1">QİYMƏT</span>
            <span className="text-2xl font-black text-white italic tracking-tighter">${product.price.toFixed(2)}</span>
          </div>
          <button 
            onClick={() => onBuy(product)}
            className="w-12 h-12 bg-primary text-black rounded-2xl shadow-lg shadow-primary/20 hover:scale-110 active:scale-95 transition-all flex items-center justify-center"
          >
            <ShoppingCart size={22} />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

const BuyModal = ({ product, isOpen, onClose, onAddToCart }: any) => {
  const [qty, setQty] = useState(1);
  const [details, setDetails] = useState({ playerId: '', server: 'Global' });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="relative w-full max-w-lg bg-dark-card border border-dark-border rounded-3xl overflow-hidden shadow-2xl"
      >
        <button onClick={onClose} className="absolute top-4 right-4 p-2 text-gray-500 hover:text-white"><X size={20}/></button>
        
        <div className="p-8">
          <div className="flex gap-4 mb-8">
            <div className="w-24 h-24 rounded-2xl overflow-hidden border border-white/5">
              <img src={product.image} className="w-full h-full object-cover" />
            </div>
            <div>
              <h2 className="text-xl font-bold mb-1">{product.name}</h2>
              <p className="text-sm text-primary font-bold">{product.game}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-2xl font-black text-white">${(product.price * qty).toFixed(2)}</span>
                <span className="text-xs text-gray-500">Total Price</span>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Required Information</label>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <span className="text-xs text-gray-400">Player ID</span>
                  <input 
                    type="text" 
                    placeholder="Enter ID" 
                    value={details.playerId}
                    onChange={(e) => setDetails({...details, playerId: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:border-primary outline-none transition-colors"
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-xs text-gray-400">Server/Region</span>
                  <select 
                    value={details.server}
                    onChange={(e) => setDetails({...details, server: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:border-primary outline-none transition-colors appearance-none"
                  >
                    <option>Global</option>
                    <option>Europe</option>
                    <option>North America</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between bg-white/5 p-4 rounded-2xl">
              <span className="text-sm font-bold">Quantity</span>
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 hover:bg-primary transition-colors"
                ><Minus size={16}/></button>
                <span className="text-lg font-black w-8 text-center">{qty}</span>
                <button 
                  onClick={() => setQty(qty + 1)}
                  className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 hover:bg-primary transition-colors"
                ><Plus size={16}/></button>
              </div>
            </div>

            <button 
              onClick={() => onAddToCart(product, qty, details)}
              className="w-full py-4 bg-primary rounded-2xl font-black text-lg shadow-xl shadow-primary/30 hover:brightness-110 active:scale-95 transition-all"
            >
              ADD TO CART
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const MobileNavbar = ({ cartCount }: any) => {
  return (
    <div className="fixed bottom-0 left-0 w-full md:hidden flex justify-between items-center px-6 py-4 glass border-t border-white/10 rounded-t-3xl z-50">
      <Link to="/" className="flex flex-col items-center gap-1 text-primary">
        <Gamepad2 size={24} />
        <span className="text-[10px] font-bold uppercase tracking-tighter">Explore</span>
      </Link>
      <Link to="/all-games" className="flex flex-col items-center gap-1 text-gray-500">
        <Menu size={24} />
        <span className="text-[10px] font-bold uppercase tracking-tighter">Games</span>
      </Link>
      <Link to="/cart" className="flex flex-col items-center gap-1 text-gray-500 relative">
        <ShoppingCart size={24} />
        <span className="text-[10px] font-bold uppercase tracking-tighter">Cart</span>
        {cartCount > 0 && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-secondary flex items-center justify-center rounded-full text-[10px] text-white font-bold">
            {cartCount}
          </span>
        )}
      </Link>
      <Link to="/help-center" className="flex flex-col items-center gap-1 text-gray-500">
        <Headset size={24} />
        <span className="text-[10px] font-bold uppercase tracking-tighter">Support</span>
      </Link>
      <Link to="/profile" className="flex flex-col items-center gap-1 text-gray-500">
        <User size={24} />
        <span className="text-[10px] font-bold uppercase tracking-tighter">Account</span>
      </Link>
    </div>
  );
};

// --- PAGES ---

const HomePage = ({ onBuy, gameFilter, categoryFilter }: any) => {
  const [activeSlide, setActiveSlide] = useState(0);

  const filteredProducts = useMemo(() => {
    let products = MOCK_PRODUCTS;
    if (gameFilter) products = products.filter(p => p.game === gameFilter);
    if (categoryFilter) products = products.filter(p => p.category === categoryFilter);
    return products;
  }, [gameFilter, categoryFilter]);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % BANNERS.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="space-y-16 pb-20">
      {/* If filtering, show simple grid, else show full homepage */}
      {(gameFilter || categoryFilter) ? (
        <section className="max-w-7xl mx-auto px-4 md:px-8 pt-10">
          <div className="flex items-center gap-4 mb-10">
            <div className="w-1.5 h-8 bg-primary rounded-full" />
            <h2 className="text-3xl font-black italic tracking-tighter uppercase">
              {gameFilter || (categoryFilter === 'GIFT' ? 'HƏDİYYƏ KARTLARI' : 'MƏHSULLAR')}
            </h2>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {filteredProducts.map((p, i) => (
              <ProductCard key={p.id + i} product={p} onBuy={onBuy} />
            ))}
          </div>
        </section>
      ) : (
        <>
          {/* Hero Banner */}
          <section className="relative h-[400px] md:h-[600px] w-full overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeSlide}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6 }}
            className="absolute inset-0"
          >
            <div className={cn("absolute inset-0 bg-gradient-to-r via-black/40 to-transparent z-10", BANNERS[activeSlide].color + "/40")} />
            <img 
              src={BANNERS[activeSlide].image} 
              className="w-full h-full object-cover"
              alt="Promotion"
            />
            <div className="absolute inset-0 z-20 flex flex-col justify-center px-4 md:px-20 max-w-5xl">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-10 h-1 bg-primary rounded-full" />
                  <span className="text-primary font-black tracking-[0.3em] text-xs md:text-sm uppercase">{BANNERS[activeSlide].subtitle}</span>
                </div>
                <h2 className="text-5xl md:text-8xl font-black text-white mb-8 tracking-tighter leading-tight drop-shadow-2xl italic uppercase">
                  {BANNERS[activeSlide].title.split(':')[0]}<br/>
                  <span className="text-primary">{BANNERS[activeSlide].title.split(':')[1]}</span>
                </h2>
                <button className="flex items-center gap-4 px-10 py-5 bg-primary text-black rounded-2xl font-black text-xl hover:bg-white hover:scale-105 active:scale-95 transition-all group shadow-[0_20px_50px_rgba(250,204,21,0.3)]">
                  İNDİ SİFARİŞ ET <ArrowRight className="group-hover:translate-x-2 transition-transform" />
                </button>
              </motion.div>
            </div>
          </motion.div>
        </AnimatePresence>
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-30 flex gap-2">
          {BANNERS.map((_, i) => (
            <button 
              key={i}
              onClick={() => setActiveSlide(i)}
              className={cn(
                "h-1 transition-all duration-500 rounded-full",
                activeSlide === i ? "w-8 bg-primary" : "w-3 bg-white/30"
              )}
            />
          ))}
        </div>
      </section>

      {/* Quick Shortcuts */}
      <section className="px-4 md:px-8 overflow-x-auto no-scrollbar scroll-smooth">
        <div className="flex gap-3 max-w-7xl mx-auto py-2">
          {QUICK_SHORTCUTS.map((title) => (
            <button 
              key={title}
              className="px-6 py-2.5 rounded-full bg-white/5 border border-white/10 text-xs font-bold whitespace-nowrap hover:bg-primary/20 hover:border-primary/50 transition-all active:scale-95"
            >
              {title}
            </button>
          ))}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { icon: Bolt, title: 'ANİ ÇATDIRILMA', desc: 'Sifarişləriniz bir neçə dəqiqə ərzində avtomatik olaraq hesabınıza köçürülür.' },
            { icon: ShieldCheck, title: 'TƏHLÜKƏSİZ ÖDƏNİŞ', desc: 'Bütün ödənişlər 3D Secure və SSL sertifikatı ilə tam qorunur.' },
            { icon: Headset, title: '7/24 DƏSTƏK', desc: 'Canlı dəstək komandamız hər bir sualınızı cavablandırmaq üçün buradadır.' }
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="bg-white/5 border border-white/5 p-8 rounded-[40px] hover:border-primary/30 transition-all text-center group"
            >
              <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-primary group-hover:text-black transition-all">
                <item.icon size={32} />
              </div>
              <h4 className="text-xl font-black mb-3 italic tracking-tighter">{item.title}</h4>
              <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Featured Grid */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-2 gap-8">
         <motion.div 
            whileHover={{ y: -5 }}
            className="relative h-64 md:h-80 rounded-[40px] overflow-hidden group cursor-pointer border border-white/5 shadow-2xl"
         >
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent z-10" />
            <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
            <div className="absolute bottom-8 left-8 z-20">
              <h3 className="text-4xl font-black text-white mb-2 italic tracking-tighter">VALORANT</h3>
              <p className="text-gray-400 font-medium mb-6 text-sm">Dünya səviyyəli rəqabətə qoşulun</p>
              <button className="px-8 py-3 bg-primary text-black rounded-2xl text-xs font-black uppercase tracking-widest group-hover:bg-white transition-all shadow-[0_10px_30px_rgba(250,204,21,0.2)]">VP AL</button>
            </div>
         </motion.div>
         <motion.div 
            whileHover={{ y: -5 }}
            className="relative h-64 md:h-80 rounded-[40px] overflow-hidden group cursor-pointer border border-white/5 shadow-2xl"
         >
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent z-10" />
            <img src="https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
            <div className="absolute bottom-8 left-8 z-20">
              <h3 className="text-4xl font-black text-white mb-2 italic uppercase tracking-tighter">PUBG Mobile</h3>
              <p className="text-gray-400 font-medium mb-6 text-sm">Döyüş sahəsinin qalibi sən ol!</p>
              <button className="px-8 py-3 bg-orange-500 text-white rounded-2xl text-xs font-black uppercase tracking-widest group-hover:bg-white group-hover:text-black transition-all shadow-[0_10px_30px_rgba(249,115,22,0.2)]">UC AL</button>
            </div>
         </motion.div>
      </section>

      {/* Categories Grid */}
      <section className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center gap-4 mb-10">
          <div className="w-1.5 h-8 bg-secondary rounded-full" />
          <h2 className="text-3xl font-black italic tracking-tighter uppercase">POPULYAR KATEQORİYALAR</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {GAME_CATEGORIES.slice(1).map((cat) => (
            <Link 
              key={cat.id} 
              to={cat.path}
              className="group bg-dark-card border border-white/5 p-6 rounded-[32px] flex flex-col items-center gap-4 hover:border-primary/50 hover:bg-primary/5 transition-all active:scale-95 shadow-xl"
            >
              <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all shadow-inner">
                <Gamepad2 size={32} />
              </div>
              <span className="font-bold text-xs text-center group-hover:text-primary transition-colors tracking-tight">{cat.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Game Sections */}
      <section className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between mb-8 border-b border-white/5 pb-4">
          <div className="flex items-center gap-4">
            <div className="w-1.5 h-8 bg-primary rounded-full" />
            <h2 className="text-3xl font-black italic tracking-tighter uppercase">PUBG MOBILE</h2>
            <div className="flex gap-4 ml-8 hidden lg:flex">
              {['PUBG ID - Global', 'PUBG E-PIN', 'PUBG ID - TR'].map((tab, i) => (
                <button key={tab} className={cn("text-xs font-bold pb-2 border-b-2 transition-all", i === 0 ? "text-primary border-primary" : "text-gray-500 border-transparent hover:text-gray-300")}>{tab}</button>
              ))}
            </div>
          </div>
          <Link to="/pubg-mobile" className="flex items-center gap-1.5 text-sm font-bold text-primary group">
            View All <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {MOCK_PRODUCTS.filter(p => p.game === 'PUBG Mobile').slice(0, 8).map((p, i) => (
            <ProductCard key={p.id + i} product={p} onBuy={onBuy} />
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between mb-8 border-b border-white/5 pb-4">
          <div className="flex items-center gap-4">
            <div className="w-1.5 h-8 bg-blue-500 rounded-full" />
            <h2 className="text-3xl font-black italic tracking-tighter uppercase">VALORANT</h2>
          </div>
          <Link to="/valorant" className="flex items-center gap-1.5 text-sm font-bold text-primary group">
            View All <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {MOCK_PRODUCTS.filter(p => p.game === 'Valorant').map((p, i) => (
            <ProductCard key={p.id + i} product={p} onBuy={onBuy} />
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between mb-8 border-b border-white/5 pb-4">
          <div className="flex items-center gap-4">
            <div className="w-1.5 h-8 bg-purple-500 rounded-full" />
            <h2 className="text-3xl font-black italic tracking-tighter uppercase">MOBILE LEGENDS</h2>
          </div>
          <Link to="/mobile-legends" className="flex items-center gap-1.5 text-sm font-bold text-primary group">
            Hamısına Bax <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {MOCK_PRODUCTS.filter(p => p.game === 'Mobile Legends').map((p, i) => (
            <ProductCard key={p.id + i} product={p} onBuy={onBuy} />
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between mb-8 border-b border-white/5 pb-4">
          <div className="flex items-center gap-4">
            <div className="w-1.5 h-8 bg-yellow-500 rounded-full" />
            <h2 className="text-3xl font-black italic tracking-tighter uppercase">BRAWL STARS</h2>
          </div>
          <Link to="/brawl-stars" className="flex items-center gap-1.5 text-sm font-bold text-primary group">
            Hamısına Bax <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {MOCK_PRODUCTS.filter(p => p.game === 'Brawl Stars').map((p, i) => (
            <ProductCard key={p.id + i} product={p} onBuy={onBuy} />
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 md:px-8 bg-white/5 rounded-[40px] py-16 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 blur-[120px] rounded-full -mr-48 -mt-48" />
        <div className="flex flex-col items-center mb-12 text-center relative z-10">
           <h2 className="text-5xl font-black italic mb-4 tracking-tighter">XƏBƏR VƏ YENİLİKLƏR</h2>
           <div className="w-24 h-1 bg-primary mb-6" />
           <p className="text-gray-400 font-medium max-w-lg">Oyun dünyasındakı ən son yeniliklərdən və endirimlərdən xəbərdar olun.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
          {[1,2,3,4].map(i => (
            <motion.div 
              key={i} 
              whileHover={{ y: -5 }}
              className="group cursor-pointer bg-dark-card/50 border border-white/5 p-4 rounded-[32px] hover:border-primary/30 transition-all"
            >
              <div className="aspect-[16/10] rounded-2xl overflow-hidden mb-4 relative shadow-lg">
                 <img src={`https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&q=80&w=400&sig=${i}`} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                 <div className="absolute top-4 left-4 px-3 py-1 bg-primary text-[10px] font-black rounded-lg text-black">Oyun Xəbərləri</div>
              </div>
              <h4 className="text-lg font-bold mb-2 group-hover:text-primary transition-colors leading-tight italic">Valorant Yenilikləri: 8.04 Yamağı</h4>
              <p className="text-sm text-gray-500 line-clamp-2">Yeni yamaq ilə gələn dəyişikliklər və yeni agent balansları haqqında ətraflı məlumat...</p>
            </motion.div>
          ))}
        </div>
        <div className="flex justify-center mt-12 relative z-10">
          <Link to="/news" className="flex items-center gap-2 px-10 py-4 bg-white/5 border border-white/10 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-primary hover:text-black transition-all shadow-inner">
            BÜTÜN XƏBƏRLƏR <ArrowRight size={14} />
          </Link>
        </div>
      </section>
    </>
    )}
    </div>
  );
};

const RegionModal = ({ isOpen, onClose, currentLang, setLang }: any) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-black/90 backdrop-blur-md" />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-3xl bg-dark-card border border-dark-border rounded-[40px] p-8 md:p-12 overflow-hidden"
      >
        <div className="text-center mb-10">
          <h2 className="text-4xl font-black italic mb-2 tracking-tighter">BÖLGƏNİZİ SEÇİN</h2>
          <p className="text-gray-500 font-medium">Bölgə seçimi mövcud məhsullara və ödəniş üsullarına təsir edir</p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10 max-h-[400px] overflow-y-auto pr-2 no-scrollbar">
          {LANGUAGES.map(lang => (
             <button 
                key={lang.code}
                onClick={() => setLang(lang)}
                className={cn(
                  "p-6 rounded-3xl border-2 flex flex-col items-center gap-3 transition-all active:scale-95",
                  currentLang.code === lang.code ? "bg-primary/20 border-primary shadow-[0_0_30px_rgba(139,92,246,0.2)]" : "bg-white/5 border-transparent hover:bg-white/10"
                )}
             >
               <span className="text-4xl">{lang.flag}</span>
               <span className="text-sm font-bold">{lang.name}</span>
             </button>
          ))}
        </div>

        <div className="flex gap-4">
          <button onClick={onClose} className="flex-1 py-4 bg-white/5 rounded-2xl font-bold hover:bg-white/10 transition-all text-gray-400">Ləğv et</button>
          <button onClick={onClose} className="flex-1 py-4 bg-primary rounded-2xl font-black text-lg shadow-xl shadow-primary/30 hover:scale-[1.02] active:scale-95 transition-all">DAVAM ET</button>
        </div>
      </motion.div>
    </div>
  );
};

// --- APP ---

export default function App() {
  const [lang, setLang] = useState(LANGUAGES[0]);
  const [currency, setCurrency] = useState(CURRENCIES[0]);
  const [users, setUsers] = useState([
    { id: '1', username: 'DemoUser', email: 'user@epincloud.com', password: 'user123', balance: 0.00, role: 'user' },
    { id: '2', username: 'Admin', email: 'admin@epincloud.com', password: 'admin123', balance: 199282828.23, role: 'admin' },
  ]);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [cart, setCart] = useState<any[]>([]);
  const [userOrders, setUserOrders] = useState<Record<string, any[]>>({
    '1': [], // DemoUser starts with 0 orders
    '2': []  // Admin starts with 0 orders
  });
  
  const [isRegionModalOpen, setRegionModalOpen] = useState(true);
  const [isSellModalOpen, setSellModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isBuyModalOpen, setBuyModalOpen] = useState(false);

  const handleBuy = (product: Product) => {
    if (!currentUser) {
       alert("Zəhmət olmasa, əvvəlcə daxil olun!");
       return;
    }
    setSelectedProduct(product);
    setBuyModalOpen(true);
  };

  const addToCart = (product: Product, quantity: number, details: any) => {
    setCart(prev => [...prev, { ...product, quantity, details, cartId: Date.now() }]);
    setBuyModalOpen(false);
    alert("Məhsul səbətə əlavə edildi!");
  };

  const removeFromCart = (cartId: number) => {
    setCart(prev => prev.filter(item => item.cartId !== cartId));
  };

  const checkout = () => {
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    if (currentUser.balance < total) {
      alert("Balansınız kifayət deyil! Zəhmət olmasa cüzdanınızı artırın.");
      return;
    }

    const newOrders = cart.map(item => ({
      ...item,
      orderId: `ORDER-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      date: new Date().toLocaleDateString('az-AZ', { day: 'numeric', month: 'long', year: 'numeric' }),
      status: 'ÇATDIRILDI'
    }));

    // Update balance
    updateBalance(currentUser.username, -total);
    
    // Update orders
    setUserOrders(prev => ({
      ...prev,
      [currentUser.id]: [...(prev[currentUser.id] || []), ...newOrders]
    }));

    // Clear cart
    setCart([]);
    alert("Sifarişiniz uğurla tamamlandı!");
  };

  const updateBalance = (username: string, amount: number) => {
    setUsers(prev => prev.map(u => u.username === username ? { ...u, balance: u.balance + amount } : u));
    setCurrentUser((prev: any) => {
      if (prev?.username === username) {
        return { ...prev, balance: prev.balance + amount };
      }
      return prev;
    });
  };

  const currentOrders = useMemo(() => {
    return currentUser ? (userOrders[currentUser.id] || []) : [];
  }, [currentUser, userOrders]);

  return (
    <Router>
      <div className="flex flex-col min-h-screen pt-[120px] md:pt-[160px]">
          <Header 
            onLangClick={() => setRegionModalOpen(true)}
            onCurrencyClick={() => setRegionModalOpen(true)}
            currentLang={lang}
            currentCurrency={currency}
            currentUser={currentUser}
            setLoggedIn={setCurrentUser}
            setSellModalOpen={setSellModalOpen}
            cartCount={cart.length}
          />

        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage onBuy={handleBuy} />} />
            <Route path="/admin" element={currentUser?.role === 'admin' ? <AdminPanel users={users} onUpdateBalance={updateBalance} /> : <LoginPage users={users} onLogin={setCurrentUser} />} />
            <Route path="/login" element={<LoginPage users={users} onLogin={setCurrentUser} />} />
            <Route path="/register" element={<RegisterPage onRegister={(u: any) => {
              setUsers([...users, u]);
              setUserOrders(prev => ({ ...prev, [u.id]: [] }));
            }} />} />
            <Route path="/profile" element={currentUser ? <AccountPage user={currentUser} type="profile" orders={currentOrders} /> : <LoginPage users={users} onLogin={setCurrentUser} />} />
            <Route path="/wallet" element={currentUser ? <AccountPage user={currentUser} type="wallet" orders={currentOrders} onAddBalance={(amt: number) => updateBalance(currentUser.username, amt)} /> : <LoginPage users={users} onLogin={setCurrentUser} />} />
            <Route path="/orders" element={currentUser ? <AccountPage user={currentUser} type="orders" orders={currentOrders} /> : <LoginPage users={users} onLogin={setCurrentUser} />} />
            <Route path="/cart" element={<CartPage cart={cart} onRemove={removeFromCart} onCheckout={checkout} currency={currency} />} />
            <Route path="/pubg-mobile" element={<HomePage onBuy={handleBuy} gameFilter="PUBG Mobile" />} />
            <Route path="/valorant" element={<HomePage onBuy={handleBuy} gameFilter="Valorant" />} />
            <Route path="/mobile-legends" element={<HomePage onBuy={handleBuy} gameFilter="Mobile Legends" />} />
            <Route path="/brawl-stars" element={<HomePage onBuy={handleBuy} gameFilter="Brawl Stars" />} />
            <Route path="/free-fire" element={<HomePage onBuy={handleBuy} gameFilter="Free Fire" />} />
            <Route path="/steam" element={<HomePage onBuy={handleBuy} gameFilter="Steam" />} />
            <Route path="/league-of-legends" element={<HomePage onBuy={handleBuy} gameFilter="League of Legends" />} />
            <Route path="/gift-cards" element={<HomePage onBuy={handleBuy} categoryFilter="GIFT" />} />
            <Route path="/all-games" element={<HomePage onBuy={handleBuy} />} />
          </Routes>
        </main>

        <Footer />
        <MobileNavbar cartCount={cart.length} />
        <LiveSupport />

        <AnimatePresence>
          <RegionModal 
            isOpen={isRegionModalOpen} 
            onClose={() => setRegionModalOpen(false)}
            currentLang={lang}
            setLang={setLang}
          />
          {selectedProduct && (
            <BuyModal 
              product={selectedProduct} 
              isOpen={isBuyModalOpen} 
              onClose={() => setBuyModalOpen(false)}
              onAddToCart={addToCart}
            />
          )}
          <SellModal 
            isOpen={isSellModalOpen} 
            onClose={() => setSellModalOpen(false)} 
          />
        </AnimatePresence>
      </div>
    </Router>
  );
}

const CartPage = ({ cart, onRemove, onCheckout, currency }: any) => {
  const total = cart.reduce((sum: number, item: any) => sum + (item.price * item.quantity), 0);

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-10">
      <div className="flex items-center gap-4 mb-10">
        <div className="p-3 bg-secondary/20 text-secondary rounded-2xl"><ShoppingCart size={32}/></div>
        <div>
          <h1 className="text-4xl font-black italic">SHOPPING CART</h1>
          <p className="text-gray-500">Review your gaming digital goods before checkout.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-6">
          {cart.length === 0 ? (
            <div className="bg-dark-card border border-white/5 rounded-[40px] p-20 text-center">
               <p className="text-gray-500 font-bold text-lg mb-6">Your cart is empty.</p>
               <Link to="/" className="px-8 py-3 bg-primary rounded-2xl font-bold text-white">Continue Shopping</Link>
            </div>
          ) : (
            cart.map((item: any) => (
              <div key={item.cartId} className="bg-dark-card border border-white/5 rounded-[40px] p-6 flex flex-col sm:flex-row items-center justify-between gap-6 hover:border-primary/30 transition-all">
                <div className="flex items-center gap-6 w-full sm:w-auto">
                  <div className="w-20 h-20 rounded-2xl overflow-hidden border border-white/5 bg-[#111115]">
                    <img src={item.image} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h3 className="font-bold">{item.name}</h3>
                    <p className="text-xs text-primary font-bold uppercase">{item.game}</p>
                    <p className="text-[10px] text-gray-500 mt-1">QTY: {item.quantity}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between w-full sm:w-auto sm:gap-10">
                  <div className="text-right">
                    <p className="font-black text-xl text-white italic">{currency.symbol}{(item.price * item.quantity).toFixed(2)}</p>
                    <p className="text-[10px] text-gray-500">Unit: {currency.symbol}{item.price.toFixed(2)}</p>
                  </div>
                  <button 
                    onClick={() => onRemove(item.cartId)}
                    className="p-3 bg-red-500/10 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all"
                  >
                    <X size={20}/>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="space-y-6">
          <div className="bg-dark-card border border-white/5 rounded-[40px] p-8">
            <h3 className="text-xl font-bold mb-8">Summary</h3>
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-gray-400 text-sm">
                <span>Subtotal</span>
                <span>{currency.symbol}{total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-400 text-sm">
                <span>Service Fee</span>
                <span className="text-green-500">FREE</span>
              </div>
              <div className="h-px bg-white/5 my-4" />
              <div className="flex justify-between text-white font-black text-2xl">
                <span>Total</span>
                <span className="text-primary italic">{currency.symbol}{total.toFixed(2)}</span>
              </div>
            </div>
            
            <button 
              disabled={cart.length === 0}
              onClick={onCheckout}
              className="w-full py-5 bg-secondary text-white rounded-2xl font-black text-xl shadow-xl shadow-secondary/20 hover:brightness-110 active:scale-95 transition-all disabled:opacity-50 disabled:grayscale"
            >
              COMPLETE CHECKOUT
            </button>
            <p className="text-[10px] text-center text-gray-500 mt-4 uppercase font-bold tracking-widest">Secured by Epincloud Payment Protection</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const LoginPage = ({ users, onLogin }: any) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: any) => {
    e.preventDefault();
    const user = users.find((u: any) => u.email === email && u.password === password);
    if (user) {
      onLogin(user);
      navigate('/');
    } else {
      alert("Hatalı e-posta veya şifre!");
    }
  };

  return (
    <div className="flex items-center justify-center p-4 min-h-[70vh]">
      <motion.div 
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-dark-card border border-dark-border rounded-[40px] p-10 shadow-2xl"
      >
        <div className="text-center mb-8">
           <h2 className="text-4xl font-black italic mb-2 tracking-tighter uppercase">Xoş Gəlmisiniz</h2>
           <p className="text-gray-500 text-sm">Epincloud hesabınıza daxil olun.</p>
           
           <div className="mt-6 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-left">
              <p className="text-[10px] font-black text-red-500 uppercase mb-2 tracking-widest">Admin Giriş Məlumatları</p>
              <div className="space-y-1 text-xs">
                <p><span className="text-gray-400">Email:</span> <span className="font-bold text-white">nah</span></p>
                <p><span className="text-gray-400">Şifrə:</span> <span className="font-bold text-white">Nah</span></p>
              </div>
           </div>
        </div>
        <form onSubmit={handleLogin} className="space-y-4">
           <div className="space-y-1">
             <label className="text-[10px] font-bold text-gray-500 uppercase px-2">Email Address</label>
             <input type="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-sm outline-none focus:border-primary transition-colors" placeholder="name@email.com" />
           </div>
           <div className="space-y-1">
             <label className="text-[10px] font-bold text-gray-500 uppercase px-2">Password</label>
             <input type="password" value={password} onChange={e => setPassword(e.target.value)} required className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-sm outline-none focus:border-primary transition-colors" placeholder="••••••••" />
           </div>
           <button className="w-full py-4 bg-primary rounded-2xl font-black text-lg shadow-xl shadow-primary/20 hover:brightness-110 transition-all mt-4">LOGIN</button>
           <div className="text-center pt-4">
             <p className="text-xs text-gray-500">Don't have an account? <Link to="/register" className="text-primary font-bold">Register Now</Link></p>
           </div>
        </form>
      </motion.div>
    </div>
  );
};

const RegisterPage = ({ onRegister }: any) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ username: '', email: '', password: '' });

  const handleRegister = (e: any) => {
    e.preventDefault();
    const newUser = { ...formData, id: Date.now().toString(), balance: 0, role: 'user' };
    onRegister(newUser);
    alert("Kayıt başarılı! Giriş yapabilirsiniz.");
    navigate('/login');
  };

  return (
    <div className="flex items-center justify-center p-4 min-h-[70vh]">
      <motion.div 
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-dark-card border border-dark-border rounded-[40px] p-10 shadow-2xl"
      >
        <div className="text-center mb-8">
           <h2 className="text-4xl font-black italic mb-2 tracking-tighter uppercase">YENİ HESAB</h2>
           <p className="text-gray-500 text-sm">Ən böyük oyun bazarına qoşulun.</p>
        </div>
        <form onSubmit={handleRegister} className="space-y-4">
           <div className="space-y-1">
             <label className="text-[10px] font-bold text-gray-500 uppercase px-2">İstifadəçi Adı</label>
             <input type="text" required value={formData.username} onChange={e => setFormData({...formData, username: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-sm outline-none focus:border-primary transition-colors" placeholder="oyuncu123" />
           </div>
           <div className="space-y-1">
             <label className="text-[10px] font-bold text-gray-500 uppercase px-2">Email</label>
             <input type="email" required value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-sm outline-none focus:border-primary transition-colors" placeholder="ad@email.com" />
           </div>
           <div className="space-y-1">
             <label className="text-[10px] font-bold text-gray-500 uppercase px-2">Şifrə</label>
             <input type="password" required value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-sm outline-none focus:border-primary transition-colors" placeholder="••••••••" />
           </div>
           <button className="w-full py-4 bg-primary rounded-2xl font-black text-lg shadow-xl shadow-primary/20 hover:brightness-110 transition-all mt-4 uppercase">QEYDİYYAT</button>
           <div className="text-center pt-4">
             <p className="text-xs text-gray-500">Artıq hesabınız var? <Link to="/login" className="text-primary font-bold">Daxil Ol</Link></p>
           </div>
        </form>
      </motion.div>
    </div>
  );
};

const SellModal = ({ isOpen, onClose }: any) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-black/90 backdrop-blur-md" />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 30 }} animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative w-full max-w-xl bg-dark-card border border-dark-border rounded-[40px] p-10 overflow-hidden shadow-[0_0_100px_rgba(139,92,246,0.15)]"
      >
        <button onClick={onClose} className="absolute top-6 right-6 p-2 text-gray-500 hover:text-white"><X size={24}/></button>
        <div className="mb-8">
          <h2 className="text-3xl font-black italic mb-2">SELL YOUR ITEMS</h2>
          <p className="text-gray-500">Reach thousands of buyers instantly on Epincloud Marketplace.</p>
        </div>
        
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Game</label>
              <select className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-sm focus:border-primary outline-none">
                <option>PUBG Mobile</option>
                <option>Valorant</option>
                <option>League of Legends</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Category</label>
              <select className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-sm focus:border-primary outline-none">
                <option>Currency</option>
                <option>E-PIN</option>
                <option>Account</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Product Information / Key</label>
            <textarea 
              placeholder="Enter your product details or keys here (one per line)..."
              className="w-full h-32 bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm focus:border-primary outline-none resize-none"
            />
          </div>

          <div className="flex items-center justify-between p-5 bg-primary/10 border border-primary/20 rounded-3xl">
             <div className="flex items-center gap-3">
               <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white"><ArrowRight size={20}/></div>
               <div>
                 <p className="text-sm font-black">Ready to list?</p>
                 <p className="text-[10px] text-gray-400">Total potential earnings will be calculated.</p>
               </div>
             </div>
             <button className="px-8 py-3 bg-primary rounded-2xl font-black shadow-lg hover:brightness-110 active:scale-95 transition-all">
                COMPLETE SALE
             </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// --- NEW PANELS ---

const PaymentModal = ({ isOpen, onClose, onConfirm }: any) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({ card: '', expiry: '', cvv: '', amount: '10' });

  if (!isOpen) return null;

  const handleSubmit = (e: any) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      onConfirm(Number(formData.amount));
      setLoading(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-black/90 backdrop-blur-md" />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-md bg-dark-card border border-dark-border rounded-[40px] p-8 shadow-2xl"
      >
        <button onClick={onClose} className="absolute top-6 right-6 p-2 text-gray-500 hover:text-white"><X size={20}/></button>
        <div className="mb-8 text-center">
          <div className="w-16 h-16 bg-accent/20 text-accent rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Wallet size={32} />
          </div>
          <h2 className="text-2xl font-black italic">SECURE PAYMENT</h2>
          <p className="text-gray-500 text-sm">Add funds safely to your Epincloud wallet.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-gray-500 uppercase px-2">Card Number</label>
            <input 
              required
              placeholder="0000 0000 0000 0000"
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-sm focus:border-accent outline-none"
              onChange={e => setFormData({...formData, card: e.target.value})}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-500 uppercase px-2">Expiry</label>
              <input required placeholder="MM/YY" className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-sm focus:border-accent outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-500 uppercase px-2">CVV</label>
              <input required placeholder="***" className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-sm focus:border-accent outline-none" />
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-gray-500 uppercase px-2">Amount ($)</label>
            <input 
              required 
              type="number" 
              value={formData.amount}
              onChange={e => setFormData({...formData, amount: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 font-black text-xl text-center focus:border-accent outline-none" 
            />
          </div>

          <button 
            disabled={loading}
            className="w-full py-4 mt-4 bg-accent text-white rounded-2xl font-black text-lg shadow-xl shadow-accent/20 hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'PROCESS PAYMENT'}
          </button>
        </form>
      </motion.div>
    </div>
  );
};

const AdminPanel = ({ users, onUpdateBalance }: any) => {
  const [targetUser, setTargetUser] = useState('');
  const [amount, setAmount] = useState(0);

  const stats = [
    { label: 'Ümumi İstifadəçi', value: users.length, icon: User, color: 'text-primary' },
    { label: 'Gözləyən Satışlar', value: '14', icon: History, color: 'text-yellow-500' },
    { label: 'Platforma Statusu', value: 'STABİL', icon: Check, color: 'text-green-500' },
    { label: 'Ümumi Dövriyyə', value: '$12,450', icon: Wallet, color: 'text-primary' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-10 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-4 bg-primary text-black rounded-3xl shadow-[0_0_30px_rgba(250,204,21,0.3)]"><LayoutDashboard size={32}/></div>
          <div>
            <h1 className="text-4xl font-black italic tracking-tighter">İDARƏETMƏ PANELİ</h1>
            <p className="text-gray-500 font-medium tracking-tight">Sistem İdarəçisi: <span className="text-primary font-black uppercase">ADMIN</span></p>
          </div>
        </div>
        <div className="flex items-center gap-3">
           <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
           <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Sistem Onlayndır</span>
        </div>
      </div>

      {/* Admin Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        {stats.map((s, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-dark-card border border-white/5 p-6 rounded-[32px] shadow-2xl"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={cn("p-2 rounded-xl bg-white/5", s.color)}><s.icon size={20}/></div>
              <span className="text-[10px] font-black text-gray-500 tracking-widest uppercase">{s.label}</span>
            </div>
            <p className="text-2xl font-black text-white italic">{s.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-dark-card border border-dark-border rounded-[40px] p-8">
            <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
              <User size={20} className="text-gray-400"/> User Registry
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-xs text-gray-500 border-b border-white/5 pb-4">
                    <th className="py-4">IDENTITY</th>
                    <th className="py-4">NETWORK</th>
                    <th className="py-4">CREDIT</th>
                    <th className="py-4">PRIVILEGE</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {users.map((u: any) => (
                    <tr key={u.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                      <td className="py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center font-bold text-[10px]">{u.username[0]}</div>
                          <span className="font-bold">{u.username}</span>
                        </div>
                      </td>
                      <td className="py-4 text-gray-400 text-xs">{u.email}</td>
                      <td className="py-4 text-accent font-black tracking-tight">${u.balance.toFixed(2)}</td>
                      <td className="py-4">
                        <span className={cn(
                          "px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest", 
                          u.role === 'admin' ? "bg-red-500/20 text-red-500" : "bg-white/10 text-gray-400"
                        )}>
                          {u.role}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-dark-card border border-red-500/20 rounded-[40px] p-8 shadow-[0_0_50px_rgba(239,68,68,0.05)]">
            <div className="flex items-center gap-2 text-red-500 mb-6">
              <div className="p-1.5 bg-red-500/10 rounded-lg"><Plus size={16}/></div>
              <h3 className="text-lg font-bold uppercase tracking-tighter">Issue Credit</h3>
            </div>
            <div className="space-y-4">
               <div>
                 <label className="text-[10px] font-bold text-gray-500 uppercase block mb-1 px-1">User Identification</label>
                 <select 
                   value={targetUser}
                   onChange={(e) => setTargetUser(e.target.value)}
                   className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3 text-sm focus:border-red-500 outline-none"
                 >
                   <option value="">Select User</option>
                   {users.map((u: any) => <option key={u.id} value={u.username}>{u.username}</option>)}
                 </select>
               </div>
               <div>
                 <label className="text-[10px] font-bold text-gray-500 uppercase block mb-1 px-1">Allocation Amount ($)</label>
                 <input 
                  type="number" 
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  placeholder="0.00"
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3 text-sm focus:border-red-500 outline-none"
                 />
               </div>
               <p className="text-[10px] text-gray-500 italic p-1">Notice: All manual allocations are logged and audited for security.</p>
               <button 
                onClick={() => { if(targetUser) onUpdateBalance(targetUser, amount); setAmount(0); }}
                className="w-full py-4 bg-red-500 text-white rounded-2xl font-black text-sm hover:brightness-110 active:scale-95 transition-all shadow-xl shadow-red-500/20"
               >
                 AUTHORIZE ALLOCATION
               </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const AccountPage = ({ user, type, orders, onAddBalance }: any) => {
  const [isPayOpen, setPayOpen] = useState(false);

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-10">
      <div className="flex flex-col md:flex-row gap-12">
        <aside className="w-full md:w-64 space-y-2">
            <Link to="/profile" className={cn("flex items-center gap-3 px-6 py-4 rounded-2xl font-bold transition-all", type === 'profile' ? "bg-primary text-white" : "hover:bg-white/5 text-gray-500")}>
              <User size={20}/> My Profile
            </Link>
            <Link to="/orders" className={cn("flex items-center gap-3 px-6 py-4 rounded-2xl font-bold transition-all", type === 'orders' ? "bg-primary text-white" : "hover:bg-white/5 text-gray-500")}>
              <History size={20}/> My Orders
            </Link>
            <Link to="/wallet" className={cn("flex items-center gap-3 px-6 py-4 rounded-2xl font-bold transition-all", type === 'wallet' ? "bg-primary text-white" : "hover:bg-white/5 text-gray-500")}>
              <Wallet size={20}/> My Wallet
            </Link>
        </aside>

        <main className="flex-1">
          {type === 'profile' && (
            <div className="bg-dark-card border border-white/5 rounded-[40px] p-10">
               <div className="flex items-center gap-6 mb-10">
                  <div className="w-24 h-24 rounded-[32px] bg-gradient-to-tr from-primary to-accent flex items-center justify-center text-4xl font-black uppercase text-white shadow-2xl">{user.username[0]}</div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h2 className="text-3xl font-black italic">{user.username}</h2>
                      <span className="px-2 py-0.5 bg-accent/20 text-accent rounded text-[10px] font-bold uppercase tracking-widest">{user.role}</span>
                    </div>
                    <p className="text-gray-500 font-medium">{user.email}</p>
                    <div className="flex gap-4 mt-6">
                      <div className="bg-white/5 px-6 py-3 rounded-2xl border border-white/5">
                        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-1">Total Orders</p>
                        <p className="text-xl font-black">{orders.length}</p>
                      </div>
                      <div className="bg-white/5 px-6 py-3 rounded-2xl border border-white/5">
                        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-1">Star Rating</p>
                        <p className="text-xl font-black text-yellow-500 flex items-center gap-1"><Star size={18} fill="currentColor"/> 4.8</p>
                      </div>
                    </div>
                  </div>
               </div>
            </div>
          )}

          {type === 'wallet' && (
            <div className="space-y-8">
               <div className="bg-gradient-to-br from-[#1a1a20] to-black border border-white/5 rounded-[40px] p-12 relative overflow-hidden shadow-2xl">
                  <div className="absolute top-0 right-0 w-80 h-80 bg-primary/20 blur-[120px] rounded-full -mr-32 -mt-32" />
                  <div className="relative z-10">
                    <p className="text-gray-400 font-bold uppercase tracking-[0.2em] mb-4">Total Balance</p>
                    <h2 className="text-7xl font-black text-white italic tracking-tighter mb-12">${user.balance.toFixed(2)}</h2>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <button 
                        onClick={() => setPayOpen(true)}
                        className="px-10 py-4 bg-primary text-white rounded-2xl font-black text-lg hover:scale-105 transition-all active:scale-95 shadow-xl shadow-primary/20 flex items-center justify-center gap-3"
                      >
                        <Plus size={20} /> TOP UP BALANCE
                      </button>
                      <button className="px-10 py-4 bg-white/5 border border-white/10 rounded-2xl font-bold hover:bg-white/10 transition-all">VIEW TRANSACTIONS</button>
                    </div>
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="p-8 bg-dark-card border border-white/5 rounded-[40px]">
                    <h3 className="font-bold mb-4 flex items-center gap-2"><CreditCard size={18} className="text-accent"/> Payment Methods</h3>
                    <div className="bg-white/5 rounded-2xl p-4 border border-white/5 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center p-2">
                           <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" className="w-full" alt="Card" />
                        </div>
                        <span className="text-sm font-bold">•••• 4242</span>
                      </div>
                      <span className="text-[10px] font-bold text-gray-500">EXPIRED</span>
                    </div>
                    <button className="w-full mt-4 py-3 border border-dashed border-white/20 rounded-2xl text-xs font-bold text-gray-400 hover:border-primary hover:text-primary transition-all">+ Add New Card</button>
                  </div>
               </div>

               <PaymentModal isOpen={isPayOpen} onClose={() => setPayOpen(false)} onConfirm={onAddBalance} />
            </div>
          )}

          {type === 'orders' && (
            <div className="bg-dark-card border border-white/5 rounded-[40px] p-8">
               <div className="flex items-center justify-between mb-8">
                 <h3 className="text-xl font-bold">Order History</h3>
                 <div className="flex gap-2">
                   {['All', 'Pending', 'Success'].map(f => (
                     <button key={f} className={cn("px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all", f === 'All' ? "bg-primary text-white" : "bg-white/5 text-gray-500 hover:bg-white/10")}>{f}</button>
                   ))}
                 </div>
               </div>
               
               {orders.length === 0 ? (
                 <div className="py-20 text-center">
                    <p className="text-gray-500 font-bold uppercase tracking-widest">No orders found yet</p>
                    <Link to="/" className="text-primary text-xs font-black mt-2 inline-block hover:underline">START SHOPPING</Link>
                 </div>
               ) : (
                 <div className="space-y-4">
                    {orders.map((p: any, i: number) => (
                      <div key={p.orderId || i} className="flex flex-col sm:flex-row items-center justify-between p-6 bg-white/5 rounded-3xl border border-white/5 hover:border-primary/30 transition-all gap-4">
                        <div className="flex items-center gap-4">
                          <div className="w-16 h-16 bg-[#111115] rounded-2xl overflow-hidden border border-white/5">
                            <img src={p.image} className="w-full h-full object-cover" />
                          </div>
                          <div>
                            <p className="font-bold text-sm">{p.name}</p>
                            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-tighter">{p.game} • {p.category}</p>
                            <p className="text-[10px] text-primary font-bold mt-1">#{p.orderId}</p>
                            <p className="text-[9px] text-gray-600 mt-0.5">{p.date}</p>
                          </div>
                        </div>
                        <div className="text-right flex flex-row sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto">
                          <p className="font-black text-xl text-white italic">${(p.price * p.quantity).toFixed(2)}</p>
                          <span className="text-[9px] font-black text-accent px-2.5 py-1 bg-accent/10 rounded-lg uppercase tracking-widest border border-accent/20">{p.status}</span>
                        </div>
                      </div>
                    ))}
                 </div>
               )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
