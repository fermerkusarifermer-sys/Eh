
export type Currency = {
  code: string;
  symbol: string;
  name: string;
  flag: string;
};

export type Language = {
  code: string;
  name: string;
  flag: string;
};

export type Product = {
  id: string;
  name: string;
  game: string;
  category: string;
  price: number;
  image: string;
  seller: string;
  rating: number;
  stock: number;
};

export type GameCategory = {
  id: string;
  name: string;
  icon: string;
  path: string;
};
