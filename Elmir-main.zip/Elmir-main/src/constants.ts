
import { Currency, Language, GameCategory } from './types';

export const LANGUAGES: Language[] = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'tr', name: 'Turkish', flag: '🇹🇷' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'it', name: 'Italian', flag: '🇮🇹' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  { code: 'vi', name: 'Vietnamese', flag: '🇻🇳' },
  { code: 'id', name: 'Indonesian', flag: '🇮🇩' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'az', name: 'Azerbaijani', flag: '🇦🇿' },
];

export const CURRENCIES: Currency[] = [
  { code: 'USD', symbol: '$', name: 'US Dollar', flag: '🇺🇸' },
  { code: 'TRY', symbol: '₺', name: 'Turkish Lira', flag: '🇹🇷' },
  { code: 'EUR', symbol: '€', name: 'Euro', flag: '🇪🇺' },
  { code: 'GBP', symbol: '£', name: 'British Pound', flag: '🇬🇧' },
  { code: 'AZN', symbol: '₼', name: 'Azerbaijani Manat', flag: '🇦🇿' },
];

export const GAME_CATEGORIES: GameCategory[] = [
  { id: '1', name: 'Bütün Məhsullar', icon: 'Gamepad2', path: '/all-games' },
  { id: '2', name: 'PUBG Mobile', icon: 'Crosshair', path: '/pubg-mobile' },
  { id: '3', name: 'Valorant', icon: 'Sword', path: '/valorant' },
  { id: '4', name: 'Mobile Legends', icon: 'Smartphone', path: '/mobile-legends' },
  { id: '5', name: 'Free Fire', icon: 'Flame', path: '/free-fire' },
  { id: '6', name: 'Brawl Stars', icon: 'Star', path: '/brawl-stars' },
  { id: '7', name: 'Steam', icon: 'Steam', path: '/steam' },
  { id: '8', name: 'League of Legends', icon: 'Shield', path: '/league-of-legends' },
  { id: '9', name: 'Hədiyyə Kartları', icon: 'CreditCard', path: '/gift-cards' },
];
